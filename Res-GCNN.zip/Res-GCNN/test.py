import time
import os
import math
import sys
import torch
import numpy as np
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import pickle
import argparse
import glob
import torch.distributions.multivariate_normal as torchdist

from utils import * 
from metrics import * 
from model import res_gcnn

import copy

import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
import random


def randomcolor():
    colorArr = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    color = ""
    for i in range(6):
        color += colorArr[random.randint(0, 14)]
    return "#" + color


# V_y_rel_to_abs =  (12, 4, 2)
# V_x_rel_to_abs =  (8, 4, 2)
# V_pred_cov =  (8, 4, 2, 2)
def batch_plot_pred_results(V_x_abs, V_y_abs, V_pred_abs, V_pred_cov, step, dataset_name):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    markersize = 8
    fontsize = 15
    linewidth = 3
    for i in range(V_x_abs.shape[1]):
        color = randomcolor()
        plt.plot(V_x_abs[:,i,0], V_x_abs[:,i,1], '-o', color=color, markersize=markersize-2, linewidth=linewidth)

        plt.plot(V_y_abs[:,i,0], V_y_abs[:,i,1], '-s', color=color, markersize=markersize-2, linewidth=linewidth)
        plt.plot([V_x_abs[-1,i,0], V_y_abs[0,i,0]], [V_x_abs[-1,i,1], V_y_abs[0,i,1]], '-', color=color, linewidth=linewidth)

        plt.plot(V_pred_abs[:,i,0], V_pred_abs[:,i,1], '-*', color=color, markersize=markersize, linewidth=linewidth)
        plt.plot([V_x_abs[-1,i,0], V_pred_abs[0,i,0]], [V_x_abs[-1,i,1], V_pred_abs[0,i,1]], '-', color=color, linewidth=linewidth)

        for j in range(V_pred_cov.shape[0]):
            cov_matrix = V_pred_cov[j,i,:,:]
            x = V_pred_abs[j,i,0]
            y = V_pred_abs[j,i,1]
            s, u = np.linalg.eig(cov_matrix)
            angle = math.atan2(u[1,0], u[0,0]) * 180 / math.pi
            # angle = math.atan2(u[0,0], u[1,0]) * 180 / math.pi
            # print("angle = ", angle)
            elli = Ellipse(xy=(x,y), width=cov_matrix[0,0]**0.5*2, height=cov_matrix[1,1]**0.5*2, angle=angle, facecolor=color, alpha=0.6)
            ax.add_patch(elli)
            # ax.add_artist(elli)
    

    plt.xlabel("X / m")
    plt.ylabel("Y / m")
    
    plt.plot([], [], 'o', color='black', markersize=markersize, label='observation')
    plt.plot([], [], 's', color='black', markersize=markersize, label='ground truth')
    plt.plot([], [], '*', color='black', markersize=markersize+2, label='prediction')
    plt.legend(fontsize=fontsize, loc=2)    # left up

    plt.axis('equal')
    # plt.axis('off')
    # plt.xticks([])
    # plt.yticks([])
    name = './results_figure_12/' + dataset_name + '-' + str(step) + '.png'
    plt.savefig(name, dpi=300, bbox_inches='tight', pad_inches=0.0)     # remove white margins
    # plt.show()


def get_parameter_number(net):
    total_num = sum(p.numel() for p in net.parameters())
    trainable_num = sum(p.numel() for p in net.parameters() if p.requires_grad)
    print('Total', total_num, 'Trainable', trainable_num)
    return {'Total': total_num, 'Trainable': trainable_num}


def test(total_time, model, loader_test, dataset_name, KSTEPS=20):
    model.eval()
    
    ade_bigls = []
    fde_bigls = []
    raw_data_dict = {}
    step = 0 # num of batch
    infer_time = []
    for batch in loader_test: 
        step += 1
        # Get data
        batch = [tensor.cuda() for tensor in batch]
        obs_traj, pred_traj_gt, obs_traj_rel, pred_traj_gt_rel, non_linear_ped,\
        loss_mask, V_obs, A_obs, V_tr, A_tr = batch

        num_of_objs = obs_traj_rel.shape[1]

        # Forward
        # V_obs = batch, seq, node, feat
        # V_obs_tmp = batch, feat, seq, node
        V_obs_tmp = V_obs.permute(0, 3, 1, 2)
        
        # calculate inference time
        torch.cuda.synchronize()
        start = time.time()
        
        V_pred, _ = model(V_obs_tmp, A_obs.squeeze())
        
        torch.cuda.synchronize()
        end = time.time()
        # print("inference time = ", end-start)
        # total_time = total_time + end-start
        infer_time.append(end-start)
        
        # print(V_pred.shape)
        # torch.Size([1, 5, 12, 2])
        # torch.Size([12, 2, 5])
        V_pred = V_pred.permute(0, 2, 3, 1)
        # torch.Size([1, 12, 2, 5]) >> seq, node, feat
        # V_pred= torch.rand_like(V_tr).cuda()

        V_tr = V_tr.squeeze()
        A_tr = A_tr.squeeze()
        V_pred = V_pred.squeeze()
        num_of_objs = obs_traj_rel.shape[1]
        V_pred, V_tr = V_pred[:, :num_of_objs, :], V_tr[:, :num_of_objs, :]
        # print(V_pred.shape)

        # For now I have my bi-variate parameters 
        # normx =  V_pred[:, :, 0:1]
        # normy =  V_pred[:, :, 1:2]
        sx = torch.exp(V_pred[:, :, 2])    # sx
        sy = torch.exp(V_pred[:, :, 3])    # sy
        corr = torch.tanh(V_pred[:, :, 4]) # corr
        
        cov = torch.zeros(V_pred.shape[0], V_pred.shape[1], 2, 2).cuda()
        cov[:, :, 0, 0] = sx * sx
        cov[:, :, 0, 1] = corr * sx * sy
        cov[:, :, 1, 0] = corr * sx * sy
        cov[:, :, 1, 1] = sy * sy
        mean = V_pred[:, :, 0:2]
        mvnormal = torchdist.MultivariateNormal(mean, cov)
        
        # Now sample 20 samples
        ade_ls = {}
        fde_ls = {}
        
        V_x = seq_to_nodes(obs_traj.data.cpu().numpy().copy())
        V_x_rel_to_abs = nodes_rel_to_nodes_abs(V_obs.data.cpu().numpy().squeeze().copy(),
                                                V_x[0, :, :].copy())

        V_y = seq_to_nodes(pred_traj_gt.data.cpu().numpy().copy())
        V_y_rel_to_abs = nodes_rel_to_nodes_abs(V_tr.data.cpu().numpy().squeeze().copy(),
                                                V_x[-1, :, :].copy())
        # 2020-10-26
        # print("V_x_rel_to_abs = ", V_x_rel_to_abs.shape)
        # print("V_y_rel_to_abs = ", V_y_rel_to_abs.shape)
        V_pred_abs = nodes_rel_to_nodes_abs(mean.data.cpu().numpy().squeeze().copy(),
                                            V_x[-1, :, :].copy())
        cov_gyw = cov.data.cpu().numpy().squeeze().copy()

        if step % 4 == 0:
            batch_plot_pred_results(V_x_rel_to_abs, V_y_rel_to_abs, V_pred_abs, cov_gyw, step, dataset_name)

        raw_data_dict[step] = {}
        raw_data_dict[step]['obs'] = copy.deepcopy(V_x_rel_to_abs)
        raw_data_dict[step]['trgt'] = copy.deepcopy(V_y_rel_to_abs)
        raw_data_dict[step]['pred'] = []

        for n in range(num_of_objs):
            ade_ls[n] = []
            fde_ls[n] = []

        for k in range(KSTEPS):
            V_pred = mvnormal.sample()

            # V_pred = seq_to_nodes(pred_traj_gt.data.numpy().copy())
            V_pred_rel_to_abs = nodes_rel_to_nodes_abs(V_pred.data.cpu().numpy().squeeze().copy(),
                                                       V_x[-1, :, :].copy())
            raw_data_dict[step]['pred'].append(copy.deepcopy(V_pred_rel_to_abs))
            
            # print(V_pred_rel_to_abs.shape) 
            # (12, 3, 2) = seq, ped, location
            for n in range(num_of_objs):
                pred = [] 
                target = []
                obsrvs = [] 
                number_of = []
                pred.append(V_pred_rel_to_abs[:, n:n+1, :])
                target.append(V_y_rel_to_abs[:, n:n+1, :])
                obsrvs.append(V_x_rel_to_abs[:, n:n+1, :])
                number_of.append(1)

                ade_ls[n].append(ade(pred, target, number_of))
                fde_ls[n].append(fde(pred, target, number_of))
        
        for n in range(num_of_objs):
            ade_bigls.append(min(ade_ls[n]))
            fde_bigls.append(min(fde_ls[n]))

    ade_ = sum(ade_bigls) / len(ade_bigls)
    fde_ = sum(fde_bigls) / len(fde_bigls)
    infer_mean_time = sum(infer_time) / len(infer_time)
    return ade_, fde_, raw_data_dict, infer_mean_time


paths = ['./checkpoint_gyw_17/**']

KSTEPS=20
print("*" * 50)
print('Number of samples:', KSTEPS)
print("*" * 50)
print()


def test_model(dataset_name, exp_path):
    print()
    print("*" * 50)
    print("Evaluating model:", exp_path)

    model_path = exp_path + '/val_best.pth'
    args_path = exp_path + '/args.pkl'
    with open(args_path, 'rb') as f: 
        args = pickle.load(f)
    #print("Args:", args)
    
    stats = exp_path + '/constant_metrics.pkl'
    with open(stats, 'rb') as f: 
        cm = pickle.load(f)
    print("Stats:", cm)

    # Data prep     
    obs_seq_len = args.obs_seq_len     # obs_seq_len=8
    pred_seq_len = args.pred_seq_len   # pred_seq_len=12
    print(dataset_name)
    data_set = './datasets/' + dataset_name + '/'

    dset_test = TrajectoryDataset(data_set + 'test/',
                                    obs_len=obs_seq_len,
                                    pred_len=pred_seq_len,
                                    skip=1,
                                    norm_lap_matr=True)
    #print("dset_test:", dset_test)
    #print("dset_test:", dset_test[0])
    
    loader_test = DataLoader(dset_test,
                                batch_size=1,
                                shuffle=False,
                                num_workers=1)
    #print("loader_test:", loader_test)

    ### Defining the model
    model = res_gcnn(n_stgcnn=args.n_stgcnn, n_txpcnn=args.n_txpcnn,
                            output_feat=args.output_size, seq_len=args.obs_seq_len,
                            kernel_size=args.kernel_size, pred_seq_len=args.pred_seq_len).cuda()
    model.load_state_dict(torch.load(model_path))
    get_parameter_number(model)
    
    # inference
    ade_ = 999999
    fde_ = 999999
    print("Testing ....")

    # torch.cuda.synchronize()
    # start = time.time()
    
    ad, fd, raw_data_dic_, infertime = test(total_time, model, loader_test, dataset_name)   
    
    # torch.cuda.synchronize()
    # end = time.time()
    # print("inference time = ", end-start)
    
    ade_ = min(ade_, ad)
    fde_ = min(fde_, fd)
    print("ADE:", ade_, " FDE:", fde_)
    return ade_, fde_, infertime


for feta in range(len(paths)):
    total_time = 0
    ade_ls = [] 
    fde_ls = []
    infertime_ls = []
    path = paths[feta]
    print(path)
    exps = glob.glob(path)[:]
    print('Model being tested are:', exps)
    
    # loop all five models, pay attention to the input subset names and the 
    # exps[]
    ade_gyw, fde_gyw, infertime_gyw = test_model('hotel', exps[0])
    ade_ls.append(ade_gyw)
    fde_ls.append(fde_gyw)
    infertime_ls.append(infertime_gyw)

    ade_gyw, fde_gyw, infertime_gyw = test_model('eth', exps[1])
    ade_ls.append(ade_gyw)
    fde_ls.append(fde_gyw)
    infertime_ls.append(infertime_gyw)
    
    ade_gyw, fde_gyw, infertime_gyw = test_model('univ', exps[2])
    ade_ls.append(ade_gyw)
    fde_ls.append(fde_gyw)
    infertime_ls.append(infertime_gyw)

    ade_gyw, fde_gyw, infertime_gyw = test_model('zara1', exps[3])
    ade_ls.append(ade_gyw)
    fde_ls.append(fde_gyw)
    infertime_ls.append(infertime_gyw)

    ade_gyw, fde_gyw, infertime_gyw = test_model('zara2', exps[4])
    ade_ls.append(ade_gyw)
    fde_ls.append(fde_gyw)
    infertime_ls.append(infertime_gyw)

    print("*" * 50)
    print("Avg ADE:", sum(ade_ls) / len(ade_ls))
    print("Avg FDE:", sum(fde_ls) / len(fde_ls))
    print("Avg Infer Time:", sum(infertime_ls) / len(infertime_ls))
import os
import math
import sys

import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as Func
from torch.nn import init
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module

import torch.optim as optim


class ConvTemporalGraphical(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,
                 t_kernel_size=1,
                 t_stride=1,
                 t_padding=0,
                 t_dilation=1,
                 bias=True):
        super(ConvTemporalGraphical, self).__init__()
        self.kernel_size = kernel_size
        self.conv = nn.Conv2d(in_channels,
                              out_channels,
                              kernel_size=(t_kernel_size, 1),
                              padding=(t_padding, 0),
                              stride=(t_stride, 1),
                              dilation=(t_dilation, 1),
                              bias=bias)

    def forward(self, x, A):
        assert A.size(0) == self.kernel_size
        x = self.conv(x)
        
        x = torch.einsum('nctv,tvw->nctw', (x, A))

        return x, A
    

class fecnn(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,
                 use_mdn = False,
                 stride=1,
                 dropout=0,
                 residual=True):
        super(fecnn, self).__init__()
        
        assert len(kernel_size) == 2
        assert kernel_size[0] % 2 == 1
        padding = ((kernel_size[0] - 1) // 2, 0)
        self.use_mdn = use_mdn

        self.fecnn = ConvTemporalGraphical(in_channels, out_channels, kernel_size[1])
        
        self.fecnn_part2 = nn.Sequential( nn.PReLU())
        
        self.tpcnn = nn.Sequential(nn.Conv2d(out_channels, 
                                           out_channels, 
                                           (kernel_size[0], 1), 
                                           (stride, 1), 
                                           padding), 
                                 nn.PReLU(),
                                 nn.Dropout(dropout, inplace=True))
        
        if not residual:
            self.residual = lambda x: 0   
        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x   
        else:
            self.residual = nn.Sequential(nn.Conv2d(in_channels, 
                                                    out_channels, 
                                                    kernel_size=1, 
                                                    stride=(stride, 1)))
        
        self.prelu = nn.PReLU()   # y = x (x>=0) || ax (x<0)
        self.bn = nn.BatchNorm2d(out_channels)

    
    def forward(self, x, A):
        res = self.residual(x)   
        
        x, A = self.fecnn(x, A)    
        x = self.fecnn_part2(x) + res

        x = self.tpcnn(x) + x    

        return x, A


class res_gcnn(nn.Module):
    def __init__(self, n_fecnn =1, n_tpcnn=1, input_feat=2, output_feat=5,
                 seq_len=8, pred_seq_len=12, kernel_size=3):
        super(res_gcnn, self).__init__()
        self.n_fecnn = n_fecnn   
        self.n_tpcnn = n_tpcnn   
                
        self.st_fecnns = nn.ModuleList()   
        self.st_fecnns.append(fecnn(input_feat, output_feat, (kernel_size, seq_len)))
        for j in range(1, self.n_fecnn):
            self.st_fecnns.append(fecnn(output_feat, output_feat, (kernel_size, seq_len)))
        
        self.tpcnns = nn.ModuleList()
        self.tpcnns.append(nn.Conv2d(seq_len, pred_seq_len, 3, padding=1))
        for j in range(1, self.n_tpcnn):
            self.tpcnns.append(nn.Conv2d(pred_seq_len, pred_seq_len, 3, padding=1))
        
        self.tpcnn_ouput = nn.Conv2d(pred_seq_len, pred_seq_len, 3, padding=1)
            
        self.prelus = nn.ModuleList()
        for j in range(self.n_tpcnn):
            self.prelus.append(nn.PReLU())

    
    def forward(self, v, a):
        for k in range(self.n_fecnn):
            v, a = self.st_fecnns[k](v, a)
            
        v = v.view(v.shape[0], v.shape[2], v.shape[1], v.shape[3])
        
        v = self.prelus[0](self.tpcnns[0](v)) + self.tpcnns[0](v)
        for k in range(1, self.n_tpcnn-1):
            v = self.prelus[k](self.tpcnns[k](v)) + v
            
        v = self.tpcnn_ouput(v) + v
        v = v.view(v.shape[0], v.shape[2], v.shape[1], v.shape[3])
        
        return v, a